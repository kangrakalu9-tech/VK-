VK HARDWARE & PLYWOODS — NETLIFY PACKAGE

Deploy:
1. Extract this ZIP file.
2. Open https://app.netlify.com/drop
3. Drag the extracted folder (the folder containing index.html) onto the page.

Files:
- index.html: complete responsive website
- assets/logo.svg: simple VK logo artwork
- assets/showroom-placeholder.svg: temporary showroom graphic

IMPORTANT:
Replace assets/showroom-placeholder.svg with your real showroom photo if desired.
If you use a JPG photo, update both image references in index.html to its new path.
The phone, WhatsApp, email and address details are based on the information supplied.
